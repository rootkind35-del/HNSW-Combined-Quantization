﻿with open('dashboard/public/js/wandb_dashboard.js', 'r', encoding='utf-8') as f:
    text = f.read()

text = text.replace('p-4.5', 'p-4')
text = text.replace('p-3.5', 'p-4')
text = text.replace('py-3.5', 'py-3')
text = text.replace('px-3.5', 'px-3')
text = text.replace('py-2.5', 'py-2')
text = text.replace('px-2.5', 'px-2')

with open('dashboard/public/js/wandb_dashboard.js', 'w', encoding='utf-8') as f:
    f.write(text)
print('Fixed padding in wandb_dashboard.js')
