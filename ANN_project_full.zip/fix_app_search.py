﻿with open('dashboard/public/js/app.js', 'r', encoding='utf-8') as f:
    text = f.read()

import re

# Find executeSearch definition
old_def = 'function executeSearch() {'
new_def = """function executeSearch() {
  if (typeof switchTab === 'function') {
    switchTab('tab-search');
  }"""
text = text.replace(old_def, new_def)

with open('dashboard/public/js/app.js', 'w', encoding='utf-8') as f:
    f.write(text)

print("Added switchTab('tab-search') to executeSearch")
