﻿with open('dashboard/public/js/app.js', 'r', encoding='utf-8') as f:
    text = f.read()

text = text.replace('p-4.5', 'p-4')
text = text.replace('p-3.5', 'p-3')

with open('dashboard/public/js/app.js', 'w', encoding='utf-8') as f:
    f.write(text)
print('Fixed p-4.5 in app.js')
