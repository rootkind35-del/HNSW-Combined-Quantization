﻿with open('dashboard/public/index.html', 'r', encoding='utf-8') as f:
    text = f.read()

import re

# Find the end of the search form
idx = text.find('triggerHnswSimulation(false)')
idx2 = text.find('</div>', idx)
idx3 = text.find('</div>', idx2 + 6)
idx_after_form = idx3 + 6

# Find the start of the live search results
idx_results = text.find('id="search-results-section-3d"')
idx_results_start = text.rfind('<!-- LIVE 3D SEARCH RESULTS SECTION', 0, idx_results)

# Extract the HUDs that need to be wrapped
huds_text = text[idx_after_form:idx_results_start]

# Wrap them inside the relative three-wrapper along with three-container
wrapped = f"""
<!-- 3D VIEWPORT WRAPPER -->
<div class="relative w-full h-[600px] bg-[#f8fafc] border border-slate-200 rounded-2xl overflow-hidden shadow-sm mt-4 mb-6" id="three-viewport-wrapper">
    <div id="three-container" class="absolute inset-0"></div>
    {huds_text.strip()}
</div>
"""

new_text = text[:idx_after_form] + "\n" + wrapped + "\n" + text[idx_results_start:]

with open('dashboard/public/index.html', 'w', encoding='utf-8') as f:
    f.write(new_text)

print('Fixed three-container and HUDs in index.html')
