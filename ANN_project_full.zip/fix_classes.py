﻿with open('dashboard/public/index.html', 'r', encoding='utf-8') as f:
    text = f.read()

# Fix invalid tailwind classes
text = text.replace('w-84', 'w-80')
text = text.replace('p-4.5', 'p-4')
text = text.replace('shadow-xs', 'shadow-sm')

with open('dashboard/public/index.html', 'w', encoding='utf-8') as f:
    f.write(text)
print('Fixed invalid tailwind classes in index.html')
