﻿with open('dashboard/public/index.html', 'r', encoding='utf-8') as f:
    text = f.read()

import re

# Check if the toggle button exists
if 'btn-toggle-params' not in text:
    idx = text.find('id="hyperparams-panel"')
    idx_start = text.rfind('<!-- HYPERPARAMETERS TUNING ACCORDION', 0, idx)
    
    toggle_btn = """
<button id="btn-toggle-params" onclick="document.getElementById('hyperparams-panel').classList.toggle('hidden')" class="w-full bg-white hover:bg-slate-50 text-slate-900 border border-slate-200 px-4 py-3 rounded-xl font-bold flex items-center justify-between transition-all duration-200 shadow-sm text-[15px]">
    <div class="flex items-center gap-2">
        <i class="fa-solid fa-sliders text-blue-800"></i> Tùy chỉnh Siêu tham số
    </div>
    <i class="fa-solid fa-chevron-down text-slate-500"></i>
</button>
"""
    new_text = text[:idx_start] + toggle_btn + "\n" + text[idx_start:]
    
    with open('dashboard/public/index.html', 'w', encoding='utf-8') as f:
        f.write(new_text)
    print("Added btn-toggle-params")
else:
    print("btn-toggle-params already exists")

