﻿with open('dashboard/public/js/app.js', 'r', encoding='utf-8') as f:
    text = f.read()

text = text.replace('text-[17px] font-bold text-slate-100', 'text-[17px] font-serif font-bold text-slate-900')

with open('dashboard/public/js/app.js', 'w', encoding='utf-8') as f:
    f.write(text)
print('Fixed text-slate-100 in app.js')
